document.writeln('<h4>Заголовок напечатан****</h4>');
let node = document.createTextNode('подзаголовок');
document.body.appendChild(node);